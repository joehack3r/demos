import boto3
ec2client = boto3.client('ec2')

def lambda_handler(event, context):
  instancesWithEvent = ec2client.describe_instance_status(
    Filters=[
      {
        'Name': 'event.code',
        'Values': [
            'instance-reboot', 'system-reboot', 'system-maintenance', 'instance-retirement', 'instance-stop' 
        ]
      },
    ],
    MaxResults=1000,
    IncludeAllInstances=False
  )

  instancesToTerminate=[]
  for index in instancesWithEvent['InstanceStatuses']:
    instancesToTerminate.append(index['InstanceId'])
  if len(instancesToTerminate) > 0:
    print("Instances to terminate: %s " % (', '.join(instancesToTerminate)))
    ec2client.terminate_instances( DryRun=False, InstanceIds=instancesToTerminate )
  else:
    print("No instances with events found.")
  return()
